package com.pavan.dao;

import org.springframework.data.repository.CrudRepository;

import com.pavan.pojo.User;

public interface MyDAO extends CrudRepository<User, String> {

}
