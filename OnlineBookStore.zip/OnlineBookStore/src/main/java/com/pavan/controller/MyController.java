package com.pavan.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.pavan.dao.MyDAO;
import com.pavan.pojo.User;

@Controller
public class MyController {
	
	@Autowired
	MyDAO dao;
	
	@RequestMapping("AuthorsLibrary")
	public ModelAndView callAuthorsLibraryPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("AuthorsLibrary");
		return mv;
	}
	@RequestMapping("ForgotPassword")
	public ModelAndView callForgotPasswordPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ForgotPassword");
		return mv;
	}
	@RequestMapping("Register")
	public ModelAndView callLoginPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Login");
		return mv;
	}
	@RequestMapping("InsertUser")
	public ModelAndView insertUserObject(User user) {
		ModelAndView mv = new ModelAndView();
		
		dao.save(user);
		
		mv.addObject("msg", "Registered Successfully");
		mv.setViewName("Login");
		return mv;
	}
	@RequestMapping("Fiction")
	public ModelAndView callFictionPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Fiction");
		return mv;
	}
	@RequestMapping("Non-Fiction")
	public ModelAndView callNonfictionPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Nonfiction");
		return mv;
	}
	@RequestMapping("Horror")
	public ModelAndView callHorrorPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Horror");
		return mv;
	}
	@RequestMapping("Fantasy")
	public ModelAndView callFantasyPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Fantasy");
		return mv;
	}
	@RequestMapping("Comedy")
	public ModelAndView callComedyPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Comedy");
		return mv;
	}
	@RequestMapping("Login")
	public ModelAndView login(User user) {
		ModelAndView mv = new ModelAndView();
		Optional<User> obj = dao.findById(user.getUsername());
        if(obj.isPresent()) {
            User tmp=obj.get();
		if(tmp.getPassword().equals(user.getPassword())) {
			mv.setViewName("Store");
		}
		else {
			mv.setViewName("AuthorsLibrary");
			mv.addObject("msg","Invalid username/password");
		}
        }
        else {
			mv.setViewName("AuthorsLibrary");
			mv.addObject("msg","Invalid username/password");
		}
		return mv;
	}
	
}
